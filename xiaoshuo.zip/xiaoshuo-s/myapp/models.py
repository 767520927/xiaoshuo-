from django.db import models

# Create your models here.


class BookName(models.Model):

    bookname = models.CharField(max_length=20)


class BookDirectory(models.Model):

    chapter = models.CharField(max_length=20)
    #bookname = models.ForeignKey("BookName", on_delete=models.CASCADE)
    bookname = models.CharField(max_length=20)


class DetailText(models.Model):

    text = models.TextField()
    #bookdirectory = models.ForeignKey("BookDirectory", on_delete=models.CASCADE)
    chapter = models.CharField(max_length=20)