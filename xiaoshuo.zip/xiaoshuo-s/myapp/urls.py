from django.conf.urls import url, include
from . import views

urlpatterns = [
    url(r'^$', views.web),
    url(r'^search', views.search),
    url(r'^detail', views.detail),
]