from django.shortcuts import render
from django.http import HttpResponse
from . import models
# Create your views here.

def web(request):
    return render(request, 'myapp/web.html')


def search(request):
    book = request.POST.get('book')
    # name = models.BookName.objects.filter(bookname=book).values_list('id')  # 将数据库去除的数据转化成所需字段的列表
    ml = models.BookDirectory.objects.filter(bookname=book)

    return render(request, 'myapp/search.html', {'book': book, 'ml': ml})


def detail(request):
    num = request.GET.get('a')
    ml = request.GET.get('ml')
    text = models.DetailText.objects.filter(id=int(num))  # .values_list('text')
    print(text)
    return render(request, 'myapp/detail.html', {'text': text, 'ml': ml})