# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request
from xiaoshuo.items import XiaoshuoItem
from scrapy_redis.spiders import RedisSpider


class XlSpider(RedisSpider):
    name = 'xl'
    allowed_domains = ['xbiquge.la']
    # start_urls = ['http://www.xbiquge.la/xiaoshuodaquan/']
    redis_key = 'xiaoshuo:start_urls'
    num = 8
    c_num = 8

    # def start_request(self,response):
    #     yield Request(url=self.start_urls[0], callback=self.parse)

    def parse(self, response):
        soup = response.css('#main > div:nth-child(1) >ul >li')
        dic = {}
        for i in soup:
            t = i.css('a::text').extract()[0]
            href = i.css('a::attr(href)').extract()[0]
            dic[t] = href
        for j in dic.items():
            print(j)
            yield Request(url=j[1], callback=self.ml_parse, meta={'name': j[0]})
            break

    def ml_parse(self,response):
        book = response.meta['name']
        soup = response.css('#list > dl > dd')
        dic = {}
        for i in soup:
            t = i.css('a::text').extract()[0]
            href = i.css('a::attr(href)').extract()[0]
            dic[t] = href
        for j in dic.items():
            nn += 1
            print(j)
            yield Request(url='http://www.xbiquge.la/'+j[1], callback=self.detail_parse, meta={'name':j[0], 'book':book})


    def detail_parse(self,response):
        self.num += 1
        self.c_num += 1
        book = response.meta['book']
        ml = response.meta['name']
        soup = response.css('#content::text').extract()
        items = XiaoshuoItem()
        items['book'] = book
        items['ml'] = ml
        items['ml_book'] = book
        items['detail_text'] = soup
        items['bookdirectory_id'] = ml
        yield items


