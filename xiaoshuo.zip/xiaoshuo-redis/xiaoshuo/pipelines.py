# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql

class XiaoshuoPipeline(object):

    def open_spider(self, spider):
        config = {
            'host' : '111.229.48.160',
            'database' : 'django',
            'user' : 'root',
            'password' : 'sheng1314',
            'port' : 3306,
            'charset' : 'utf8'
        }
        self.connect = pymysql.connect(**config)
        self.cursor1 = self.connect.cursor()
        self.cursor2 = self.connect.cursor()
        self.cursor3 = self.connect.cursor()

    def process_item(self, item, spider):
        sql1 = 'insert into myapp_bookname (id,bookname) values (%s,%s)'
        sql2 = 'insert into myapp_bookdirectory(id,chapter,bookname) values (%s,%s,%s)'
        sql3 = 'insert into myapp_detailtext(id,text,chapter) values (%s,%s,%s)'
        self.cursor1.execute(sql1,(None,str(item['book'])))
        #self.connect.commit()
        self.cursor2.execute(sql2,(None,item['ml'],item['ml_book']))
        #self.connect.commit()
        self.cursor3.execute(sql3,(None,''.join(item['detail_text']),item['bookdirectory_id']))
        self.connect.commit()
        return item

    def close_spider(self, spider):
        self.connect.close()
